<?php 
include 'koneksi.php';
 ?>
 <html>
<head>
<title>Transaksi MCS</title>
<link rel="stylesheet" type="text/css" href="asset/style.css">
</head>
<body>
<nav>
<ul class="kiri">
<li><a href="">Transaksi MCS</a></li>
</ul>
<ul class="kanan">
</ul><div style="clear:both"></div>
</nav>
<div class="sidebar">
<ul>
<li><a href="home.php">Admin</a></li>
<li><a href="maker.php">Maker</a></li>
<li><a href="checker.php">Checker</a></li>
<li><a href="signer.php">Signer</a></li>

</ul>
</div>
<div class="main">
	<div class="isimain">
			<span class="span">Form Edit Data</span>
			<?php 
				include 'koneksi.php';
				$data = mysqli_query($koneksi,"SELECT * FROM transaksi ORDER BY no_order");
				$no=1;
				while ($r = mysqli_fetch_array($data)) {
					?>
					<form action="pro_edit.php" method="POST">
					<input type="text" name="no_order" placeholder="No Order"><br>
					<input type="text" name="nama_order" placeholder="Nama Order"><br>
					<input type="text" name="no_hp" placeholder="No Hp (aktif WA)"><br>
					<input type="text" name="jumlah_penumpang" placeholder="Jumlah Penumpang"><br>
					<input type="text" name="rute" placeholder="Rute"><br>
					<input type="date" name="tanggal_order" placeholder="Tanggal Order"><br>
					<input type="text" name="maskapai" placeholder="Maskapai"><br>
					<input type="time" name="jam_mendarat" placeholder="Jam Mendarat"><br>
					<input type="text" name="alamat_jemput" placeholder="Alamat Jemput"><br>
					<input type="text" name="alamat_tujuan" placeholder="Alamat Tujuan"><br>
					<input type="time" name="jam_penjemputan" placeholder="Jam Penjemputan"><br>
					<input type="text" name="partner" placeholder="Partner"><br>
					<input type="text" name="status" placeholder="Status"><br>
					<input type='submit' placeholder='submit'>
					</form>

					<?php
				}
			 ?>
			
	</div>
</div>
</body>
</html>
