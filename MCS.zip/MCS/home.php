<?php require_once("koneksi.php");
    if (!isset($_SESSION)) {
        session_start();
    } ?>
<!DOCTYPE html>
<html>
<head>
	<title>Transaksi MCS</title>
</head>
<link rel="stylesheet" type="text/css" href="asset/style.css">
<body>
<nav>
	<ul class="kiri">
		<li><a href="">Transaksi MCS</a></li>
	</ul>
	<ul class="kanan">
		<li><a href="">Hello</a></li>
		<div style="clear:both"></div>
	</ul>
</nav>
<div class="sidebar">
		<ul>
			<li><a href="home.php">Admin</a></li>
			<li><a href="maker.php">Maker</a></li>
			<li><a href="checker.php">Checker</a></li>
			<li><a href="signer.php">Signer</a></li>
		</ul>
	</div>
<style type="text/css">
td,th{border:1px solid #ccc;padding:10px;}
table{border-collapse:collapse;}
</style>
<div class="main">
	<div class="isimain">
		<table>
		<a href="tambah.php"><input type="submit" value="Tambah Data"></a>
			<tr>
				<th>id</th><th>Nama</th><th>Username</th><th>Password</th><th>Email</th><th>Level</th><th>Action</th>
			</tr>
			<?php 
				include 'koneksi.php';
				$data = mysqli_query($koneksi,"SELECT * FROM login ORDER BY username");
				$no=1;
				while ($r = mysqli_fetch_array($data)) {
					?>
					 <tr>
			 	<td><?php echo $r['id']; ?></td>
			 	<td><?php echo $r['nama']; ?></td>
			 	<td><?php echo $r['username']; ?></td>
			 	<td><?php echo $r['password']; ?></td>
			 	<td><?php echo $r['email']; ?></td>
			 	<td><?php echo $r['level']; ?></td>
			 	<td>
				<a href="edit.php?id=<?php echo $r['id']; ?>">EDIT</a>
				<a href="hapus_admin.php?id=<?php echo $r['id'];?>">DELETE</a></td>
			 </tr>
					<?php
				}
			 ?>

		</table>	
	</div>
</div>
</body>
</html>