<?php 
include 'koneksi.php';
$no_order=$_POST['no_order'];
$nama_order=$_POST['nama_order'];
$no_hp=$_POST['no_hp'];
$jumlah_penumpang=$_POST['jumlah_penumpang'];
$rute=$_POST['rute'];
$tanggal_order=$_POST['tanggal_order'];
$maskapai=$_POST['maskapai'];
$jam_mendarat=$_POST['jam_mendarat'];
$alamat_jemput=$_POST['alamat_jemput'];
$alamat_tujuan=$_POST['alamat_tujuan'];
$jam_penjemputan=$_POST['jam_penjemputan'];
$partner=$_POST['partner'];
$status=$_POST['status'];

mysqli_query
($koneksi,"UPDATE `transaksi` SET `no_order`=[value-1],`nama_order`=[value-2],`no_hp`=[value-3],`jumlah_penumpang`=[value-4],`rute`=[value-5],`tanggal_order`=[value-6],
`maskapai`=[value-7],`jam_mendarat`=[value-8],`alamat_jemput`=[value-9],`alamat_tujuan`=[value-10],`jam_penjemputan`=[value-11],`partner`=[value-12],`status`=[value-13] WHERE 'no_order'") 
 or die(mysqli_connect_errno());

 header("location:http://localhost/MCS/maker.php");     


 ?>