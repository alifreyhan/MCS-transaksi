<?php 
include 'koneksi.php';
 ?>
<?php 
$id =$_GET['id'];
$db=mysqli_query($koneksi,"DELETE FROM transaksi WHERE id='$id'") or die(mysqli_connect_errno());
{?> 
<script type="text/javascript">
	alert("Anda Yakin ??");
	window.location.href="maker.php";
</script>

<?php } ?>
