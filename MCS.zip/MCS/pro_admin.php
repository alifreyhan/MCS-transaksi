<?php include 'koneksi.php';

$id=$_POST['id'];
$nama=$_POST['nama'];
$username=$_POST['username'];
$password=$_POST['password'];
$email=$_POST['email'];
$level=$_POST['level'];


mysqli_query
($koneksi,"INSERT INTO `login`(`id`, `nama`, `username`, `password`, `email`, `level`)
 VALUES ('$id','$nama','$username','$password','$email','$level')") 
 or die(mysqli_connect_errno());

 header("location:http://localhost/MCS/home.php");                
	
 ?>