<?php 
include 'koneksi.php';
 ?>
<?php 
$id =$_GET['id'];
$db=mysqli_query($koneksi,"DELETE FROM `login` WHERE `id=0`") or die(mysqli_connect_errno());
{?> 
<script type="text/javascript">
	alert("Anda Yakin ??");
	window.location.href="home.php";
</script>

<?php } ?>
