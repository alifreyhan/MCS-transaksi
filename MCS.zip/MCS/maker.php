<?php 
include 'koneksi.php';
 ?>
<html>
<head>
<title>Transaksi MCS</title>
<link rel="stylesheet" type="text/css" href="asset/style.css">
</head>
<body>
<nav>
<ul class="kiri">
<li><a href="">Transaksi MCS</a></li>
</ul>
<ul class="kanan">
</ul><div style="clear:both"></div>
</nav>
<div class="sidebar">
<ul>
<li><a href="home.php">Admin</a></li>
<li><a href="maker.php">Maker</a></li>
<li><a href="checker.php">Checker</a></li>
<li><a href="signer.php">Signer</a></li>
</ul>
</div>
<style type="text/css">
td,th{border:1px solid #ccc;padding:10px;}
table{border-collapse:collapse;}
</style>
<div class="main">
	<div class="isimain">
		<table>
			<a href="input.php"><input type="submit" value="Tambah Data"></a>
			<tr>
				<th>No Order</th><th>Nama Order</th><th>No Hp</th><th>Jumlah Penumpang</th><th>Rute</th><th>Tanggal Order</th>
				<th>Maskapai</th><th>Jam Mendarat</th><th>Alamat Jemput</th><th>Alamat Tujuan</th><th>Jam Penjemputan</th><th>Partner</th><th>Status</th><th>Action</th>
			</tr>
			<?php 
				include 'koneksi.php';
				$data = mysqli_query($koneksi,"SELECT * FROM transaksi ORDER BY no_order");
				$no=1;
				while ($r = mysqli_fetch_array($data)) {
					?>
					 <tr>
			 	<td><?php echo $r['no_order']; ?></td>
			 	<td><?php echo $r['nama_order']; ?></td>
			 	<td><?php echo $r['no_hp']; ?></td>
			 	<td><?php echo $r['jumlah_penumpang']; ?></td>
			 	<td><?php echo $r['rute']; ?></td>
			 	<td><?php echo $r['tanggal_order']; ?></td>
				<td><?php echo $r['maskapai']; ?></td>
			 	<td><?php echo $r['jam_mendarat']; ?></td>
			 	<td><?php echo $r['alamat_jemput']; ?></td>
			 	<td><?php echo $r['alamat_tujuan']; ?></td>
			 	<td><?php echo $r['jam_penjemputan']; ?></td>
			 	<td><?php echo $r['partner']; ?></td>
				<td><?php echo $r['status']; ?></td>
			 	<td>
				<a href="edit.php?id=<?php echo $r['id']; ?>">EDIT</a>
				<a href="hapus.php?id=<?php echo $r['id'];?>">HAPUS</a></td>
			 </tr>
					<?php
				}
			 ?>

		</table>	
	</div>
</div>
</body>
</html>