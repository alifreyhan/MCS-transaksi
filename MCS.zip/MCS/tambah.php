
<!DOCTYPE html>
<html>
<head>
	<title>Transaksi MCS</title>
</head>
<link rel="stylesheet" type="text/css" href="asset/style.css">
<body>
<nav>
	<ul class="kiri">
		<li><a href="">Transaksi MCS</a></li>
	</ul>
	<ul class="kanan">
		<li><a href="">Hello</a></li>
		<div style="clear:both"></div>
	</ul>
</nav>
<div class="sidebar">
		<ul>
			<li><a href="home.php">Admin</a></li>
			<li><a href="maker.php">Maker</a></li>
			<li><a href="checker.php">Checker</a></li>
			<li><a href="signer.php">Signer</a></li>
		</ul>
	</div>
<div class="main">
	<div class="isimain">
		<span class="span">Input Data</span>
			<form action="pro_admin.php" method="POST">
				<input type="text" name="id" placeholder="id"><br>
				<input type="text" name="nama" placeholder="Nama"><br>
				<input type="text" name="username" placeholder="Username"><br>
				<input type="text" name="password" placeholder="Password"><br>
				<input type="text" name="email" placeholder="Email"><br>
				<input type="text" name="level" placeholder="Level"><br>
				<input type="submit" value="Simpan Data">
			</form>
	</div>
</div>
</body>
</html>
