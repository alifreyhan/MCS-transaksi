-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 01 Jul 2018 pada 21.31
-- Versi server: 10.1.32-MariaDB
-- Versi PHP: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `transaksi_mcs`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `anggota`
--

CREATE TABLE `anggota` (
  `id_anggota` varchar(5) NOT NULL,
  `nama_anggota` varchar(200) NOT NULL,
  `gender` char(2) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `level` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `anggota`
--

INSERT INTO `anggota` (`id_anggota`, `nama_anggota`, `gender`, `alamat`, `level`) VALUES
('tbk01', 'Alif reyhan arinta', 'L', 'malang', 'Admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `id` int(5) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(50) NOT NULL,
  `level` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`id`, `nama`, `username`, `password`, `email`, `level`) VALUES
(1, 'Alif reyhan arinta', 'humam', '123456789', 'alifarinta@gmail.com', 'Admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_check`
--

CREATE TABLE `tbl_check` (
  `no_order` varchar(10) NOT NULL,
  `nama_order` varchar(50) NOT NULL,
  `no_hp` int(255) NOT NULL,
  `jumlah_penumpang` varchar(50) NOT NULL,
  `rute` varchar(200) NOT NULL,
  `tanggal_order` date NOT NULL,
  `maskapai` varchar(200) NOT NULL,
  `jam_mendarat` time NOT NULL,
  `alamat_jemput` varchar(200) NOT NULL,
  `alamat_tujuan` varchar(200) NOT NULL,
  `jam_penjemputan` time NOT NULL,
  `partner` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_check`
--

INSERT INTO `tbl_check` (`no_order`, `nama_order`, `no_hp`, `jumlah_penumpang`, `rute`, `tanggal_order`, `maskapai`, `jam_mendarat`, `alamat_jemput`, `alamat_tujuan`, `jam_penjemputan`, `partner`, `status`) VALUES
('TR 00130 M', 'order', 891231231, '1', 'jakarta - malang', '2018-05-18', 'batik air', '20:00:00', 'juanda', 'jl.sawojajar malang', '20:00:00', 'diah', 'in progres');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_signer`
--

CREATE TABLE `tbl_signer` (
  `no_order` varchar(10) NOT NULL,
  `nama_order` varchar(50) NOT NULL,
  `no_hp` int(255) NOT NULL,
  `jumlah_penumpang` int(50) NOT NULL,
  `rute` varchar(200) NOT NULL,
  `tanggal_order` date NOT NULL,
  `maskapai` varchar(200) NOT NULL,
  `jam_mendarat` time NOT NULL,
  `alamat_jemput` varchar(200) NOT NULL,
  `alamat_tujuan` varchar(200) NOT NULL,
  `jam_penjemputan` time NOT NULL,
  `partner` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_signer`
--

INSERT INTO `tbl_signer` (`no_order`, `nama_order`, `no_hp`, `jumlah_penumpang`, `rute`, `tanggal_order`, `maskapai`, `jam_mendarat`, `alamat_jemput`, `alamat_tujuan`, `jam_penjemputan`, `partner`, `status`) VALUES
('TR 00130 M', 'order', 891231231, 1, 'jakarta - malang', '2018-05-18', 'batik air', '20:00:00', 'juanda', 'jl.sawojajar malang', '20:00:00', 'diah', 'in progres');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `no_order` varchar(10) NOT NULL,
  `nama_order` varchar(50) NOT NULL,
  `no_hp` int(200) NOT NULL,
  `jumlah_penumpang` int(50) NOT NULL,
  `rute` varchar(200) NOT NULL,
  `tanggal_order` date NOT NULL,
  `maskapai` varchar(200) NOT NULL,
  `jam_mendarat` time NOT NULL,
  `alamat_jemput` varchar(200) NOT NULL,
  `alamat_tujuan` varchar(200) NOT NULL,
  `jam_penjemputan` time NOT NULL,
  `partner` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`no_order`, `nama_order`, `no_hp`, `jumlah_penumpang`, `rute`, `tanggal_order`, `maskapai`, `jam_mendarat`, `alamat_jemput`, `alamat_tujuan`, `jam_penjemputan`, `partner`, `status`) VALUES
('TR 00130 M', 'order', 891231231, 1, 'jakarta - malang', '2018-05-18', 'batik air', '20:00:00', 'juanda', 'jl.sawojajar malang', '20:00:00', 'diah', 'in progres');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`id_anggota`);

--
-- Indeks untuk tabel `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`,`nama`,`username`,`password`,`email`,`level`);

--
-- Indeks untuk tabel `tbl_check`
--
ALTER TABLE `tbl_check`
  ADD PRIMARY KEY (`no_order`);

--
-- Indeks untuk tabel `tbl_signer`
--
ALTER TABLE `tbl_signer`
  ADD PRIMARY KEY (`no_order`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`no_order`),
  ADD KEY `id_transaksi` (`no_order`,`nama_order`,`no_hp`,`jumlah_penumpang`,`rute`,`tanggal_order`,`maskapai`,`jam_mendarat`,`alamat_jemput`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `login`
--
ALTER TABLE `login`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
